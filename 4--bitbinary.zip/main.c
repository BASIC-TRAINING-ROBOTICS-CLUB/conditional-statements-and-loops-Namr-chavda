#include<stdio.h>

void comparator(unsigned char a, unsigned char b)
{
    if(a==b){
        printf("number are equal: %hhu and %hhu\n",a,b);
    }
    else if(a>b){
        printf("%hhu is greater than %hhu \n",a,b);
    }
    else
    {
        printf("%hhu is less than %hhu",a,b);
    }
}

int main()
{
    unsigned char a,b;
    printf("enter first 4-bit binary number (0-15):");
    scanf("%hhu",&a);
    printf("enter second 4-bit binarey number (0-15):");
    scanf("%hhu",&b);
    
    comparator(a,b);
    
    return 0;
}
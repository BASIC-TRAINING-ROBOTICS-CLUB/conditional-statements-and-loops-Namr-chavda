#ifndef COMARATOR_H
#define COMARATOR_H

void comparator(unsigned char a,unsigned char b);
#endif

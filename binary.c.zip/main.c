#include<stdio.h>
#include"comparator.h"
int main()
{
    unsigned char a,b;
    printf("enter first 4-bit binary number (0-15):");
    scanf("%hhu",&a);
    
    printf("enter second 4-bit binarey number (0-15):");
    scanf("%hhu",&b);
    
    comparator(a,b);
    
    return 0;
}
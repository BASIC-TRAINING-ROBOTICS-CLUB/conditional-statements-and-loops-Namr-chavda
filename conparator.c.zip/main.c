


#include "comparator.h"

void comparator(unsigned char a, unsigned char b)
{
    if(a==b){
        printf("number are equal: %hhu and %hhu\n",a,b);
    }
    else if(a>b){
        printf("%hhu is greater than %hhu \n",a,b);
    }
    else
    {
        printf("%hhu is less than %hhu",a,b);
    }
}
